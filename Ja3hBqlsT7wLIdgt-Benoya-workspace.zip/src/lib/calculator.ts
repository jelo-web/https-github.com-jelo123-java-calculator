export type Operator = "add" | "subtract" | "multiply" | "divide";

export const OPERATOR_SYMBOL: Record<Operator, string> = {
  add: "+",
  subtract: "−",
  multiply: "×",
  divide: "÷",
};

export type HistoryEntry = {
  id: string;
  expression: string;
  result: string;
};

export type CalcState = {
  display: string;
  accumulator: number | null;
  operator: Operator | null;
  overwrite: boolean;
  error: string | null;
  expression: string;
  history: HistoryEntry[];
};

export const initialState: CalcState = {
  display: "0",
  accumulator: null,
  operator: null,
  overwrite: true,
  error: null,
  expression: "",
  history: [],
};

const MAX_DIGITS = 12;
const DIV_ZERO = "Can't divide by zero";

export type Action =
  | { type: "digit"; digit: string }
  | { type: "dot" }
  | { type: "operator"; operator: Operator }
  | { type: "equals" }
  | { type: "clear" }
  | { type: "backspace" }
  | { type: "sign" }
  | { type: "percent" }
  | { type: "hydrate"; history: HistoryEntry[] }
  | { type: "recall"; entry: HistoryEntry };

function parseDisplay(display: string): number {
  const n = Number(display);
  return Number.isFinite(n) ? n : 0;
}

export function formatResult(n: number): string {
  if (!Number.isFinite(n)) return "Error";
  const rounded = Math.round(n * 1e12) / 1e12;
  if (Object.is(rounded, -0)) return "0";
  const abs = Math.abs(rounded);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-8)) {
    return rounded.toExponential(6).replace(/\.?0+e/, "e");
  }
  return String(rounded);
}

function apply(a: number, b: number, op: Operator): number | "div0" {
  if (op === "divide" && b === 0) return "div0";
  if (op === "add") return a + b;
  if (op === "subtract") return a - b;
  if (op === "multiply") return a * b;
  return a / b;
}

function digitCount(display: string): number {
  return display.replace("-", "").replace(".", "").length;
}

function fresh(state: CalcState, patch: Partial<CalcState>): CalcState {
  return { ...initialState, history: state.history, ...patch };
}

export function reduce(state: CalcState, action: Action): CalcState {
  switch (action.type) {
    case "hydrate":
      return { ...state, history: action.history.slice(0, 12) };

    case "recall":
      return fresh(state, {
        display: action.entry.result,
        expression: action.entry.expression,
        overwrite: true,
      });

    case "clear":
      return fresh(state, {});

    case "digit": {
      const base = state.error ? fresh(state, {}) : state;
      if (base.overwrite) {
        return {
          ...base,
          display: action.digit,
          overwrite: false,
          expression: base.operator ? base.expression : "",
          error: null,
        };
      }
      if (digitCount(base.display) >= MAX_DIGITS) return base;
      if (base.display === "0") return { ...base, display: action.digit };
      if (base.display === "-0") return { ...base, display: `-${action.digit}` };
      return { ...base, display: base.display + action.digit };
    }

    case "dot": {
      const base = state.error ? fresh(state, {}) : state;
      if (base.overwrite) {
        return {
          ...base,
          display: "0.",
          overwrite: false,
          expression: base.operator ? base.expression : "",
          error: null,
        };
      }
      if (base.display.includes(".")) return base;
      return { ...base, display: `${base.display}.` };
    }

    case "sign": {
      if (state.error) return state;
      if (state.display.startsWith("-")) {
        return { ...state, display: state.display.slice(1) || "0" };
      }
      if (state.display === "0") return { ...state, display: "-0", overwrite: false };
      return { ...state, display: `-${state.display}` };
    }

    case "percent": {
      if (state.error) return state;
      return {
        ...state,
        display: formatResult(parseDisplay(state.display) / 100),
        overwrite: true,
      };
    }

    case "backspace": {
      if (state.error || state.overwrite) return state;
      if (
        state.display.length <= 1 ||
        (state.display.startsWith("-") && state.display.length <= 2)
      ) {
        return { ...state, display: "0", overwrite: true };
      }
      return { ...state, display: state.display.slice(0, -1) };
    }

    case "operator": {
      if (state.error) return state;
      const current = parseDisplay(state.display);
      if (state.accumulator !== null && state.operator && !state.overwrite) {
        const result = apply(state.accumulator, current, state.operator);
        if (result === "div0") {
          return {
            ...state,
            error: DIV_ZERO,
            expression: `${formatResult(state.accumulator)} ÷ ${formatResult(current)}`,
          };
        }
        const text = formatResult(result);
        return {
          ...state,
          display: text,
          accumulator: result,
          operator: action.operator,
          overwrite: true,
          error: null,
          expression: `${text} ${OPERATOR_SYMBOL[action.operator]}`,
        };
      }
      return {
        ...state,
        accumulator: current,
        operator: action.operator,
        overwrite: true,
        expression: `${formatResult(current)} ${OPERATOR_SYMBOL[action.operator]}`,
      };
    }

    case "equals": {
      if (state.error || state.operator === null || state.accumulator === null) return state;
      const current = parseDisplay(state.display);
      const result = apply(state.accumulator, current, state.operator);
      const left = formatResult(state.accumulator);
      const right = formatResult(current);
      const expression = `${left} ${OPERATOR_SYMBOL[state.operator]} ${right}`;
      if (result === "div0") {
        return { ...state, error: DIV_ZERO, expression };
      }
      const text = formatResult(result);
      const entry: HistoryEntry = {
        id: `${Date.now()}`,
        expression,
        result: text,
      };
      return {
        ...state,
        display: text,
        accumulator: null,
        operator: null,
        overwrite: true,
        error: null,
        expression,
        history: [entry, ...state.history].slice(0, 12),
      };
    }

    default:
      return state;
  }
}
