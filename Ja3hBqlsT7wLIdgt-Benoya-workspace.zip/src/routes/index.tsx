import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useReducer, useState } from "react";
import { Delete } from "lucide-react";
import {
  OPERATOR_SYMBOL,
  initialState,
  reduce,
  type HistoryEntry,
  type Operator,
} from "@/lib/calculator";

export const Route = createFileRoute("/")({ component: Home });

const STORAGE_KEY = "tally-history";

const DIGITS = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "0"] as const;

function isHistoryEntry(value: unknown): value is HistoryEntry {
  if (!value || typeof value !== "object") return false;
  const entry = value as HistoryEntry;
  return (
    typeof entry.id === "string" &&
    typeof entry.expression === "string" &&
    typeof entry.result === "string"
  );
}

function Home() {
  const [state, dispatch] = useReducer(reduce, initialState);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          dispatch({ type: "hydrate", history: parsed.filter(isHistoryEntry) });
        }
      }
    } catch {
      /* ignore a corrupt tape */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.history));
  }, [ready, state.history]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const key = event.key;
      if (/^[0-9]$/.test(key)) {
        dispatch({ type: "digit", digit: key });
        return;
      }
      const ops: Record<string, Operator> = {
        "+": "add",
        "-": "subtract",
        "*": "multiply",
        "/": "divide",
      };
      if (ops[key]) {
        event.preventDefault();
        dispatch({ type: "operator", operator: ops[key] });
        return;
      }
      if (key === "Enter" || key === "=") {
        event.preventDefault();
        dispatch({ type: "equals" });
        return;
      }
      if (key === ".") dispatch({ type: "dot" });
      else if (key === "Backspace") dispatch({ type: "backspace" });
      else if (key === "Escape") dispatch({ type: "clear" });
      else if (key === "%") dispatch({ type: "percent" });
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const readout = state.error ?? state.display;
  const compact = readout.length > 10;

  return (
    <main className="flex min-h-svh items-center justify-center bg-bg px-4 py-8 text-fg">
      <div className="flex w-full max-w-sm flex-col gap-5">
        <header className="flex items-baseline justify-between px-1">
          <h1 className="text-sm font-medium tracking-widest text-muted uppercase">Tally</h1>
          <p className="text-sm text-muted">Calculator</p>
        </header>

        <section
          className="rounded-panel border border-line bg-surface px-5 py-5"
          aria-live="polite"
        >
          <p className="min-h-5 truncate text-right font-mono text-sm text-muted">
            {state.expression || "\u00a0"}
          </p>
          <p
            className={
              "mt-2 truncate text-right font-mono font-medium " +
              (state.error ? "text-3xl text-accent " : compact ? "text-3xl text-fg " : "text-5xl text-fg ")
            }
          >
            {readout}
          </p>
        </section>

        {state.history.length > 0 ? (
          <ul className="flex max-h-28 flex-col gap-1 overflow-auto px-1">
            {state.history.slice(0, 4).map((entry) => (
              <li key={entry.id}>
                <button
                  type="button"
                  onClick={() => dispatch({ type: "recall", entry })}
                  className="flex w-full items-baseline justify-between gap-3 rounded-xl px-2 py-1 text-left font-mono text-sm text-muted hover:bg-surface hover:text-fg"
                >
                  <span className="truncate">{entry.expression}</span>
                  <span className="shrink-0 text-fg">{entry.result}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="px-1 text-sm text-muted">Type or tap. History stays on this device.</p>
        )}

        <section className="grid grid-cols-4 gap-2">
          <Key label="C" tone="ghost" onPress={() => dispatch({ type: "clear" })} />
          <Key label="±" tone="ghost" onPress={() => dispatch({ type: "sign" })} />
          <Key label="%" tone="ghost" onPress={() => dispatch({ type: "percent" })} />
          <Key
            label={OPERATOR_SYMBOL.divide}
            tone="op"
            active={state.operator === "divide"}
            onPress={() => dispatch({ type: "operator", operator: "divide" })}
          />

          {DIGITS.slice(0, 3).map((digit) => (
            <Key key={digit} label={digit} onPress={() => dispatch({ type: "digit", digit })} />
          ))}
          <Key
            label={OPERATOR_SYMBOL.multiply}
            tone="op"
            active={state.operator === "multiply"}
            onPress={() => dispatch({ type: "operator", operator: "multiply" })}
          />

          {DIGITS.slice(3, 6).map((digit) => (
            <Key key={digit} label={digit} onPress={() => dispatch({ type: "digit", digit })} />
          ))}
          <Key
            label={OPERATOR_SYMBOL.subtract}
            tone="op"
            active={state.operator === "subtract"}
            onPress={() => dispatch({ type: "operator", operator: "subtract" })}
          />

          {DIGITS.slice(6, 9).map((digit) => (
            <Key key={digit} label={digit} onPress={() => dispatch({ type: "digit", digit })} />
          ))}
          <Key
            label={OPERATOR_SYMBOL.add}
            tone="op"
            active={state.operator === "add"}
            onPress={() => dispatch({ type: "operator", operator: "add" })}
          />

          <Key label="0" onPress={() => dispatch({ type: "digit", digit: "0" })} />
          <Key label="." onPress={() => dispatch({ type: "dot" })} />
          <Key
            label="Backspace"
            tone="ghost"
            icon
            onPress={() => dispatch({ type: "backspace" })}
          />
          <Key label="=" tone="equals" onPress={() => dispatch({ type: "equals" })} />
        </section>
      </div>
    </main>
  );
}

function Key({
  label,
  onPress,
  tone = "digit",
  active = false,
  icon = false,
}: {
  label: string;
  onPress: () => void;
  tone?: "digit" | "op" | "ghost" | "equals";
  active?: boolean;
  icon?: boolean;
}) {
  const tones = {
    digit: "bg-key text-fg",
    op: active ? "bg-accent text-accent-ink" : "bg-key-strong text-fg",
    ghost: "bg-surface text-muted",
    equals: "bg-accent text-accent-ink",
  } as const;

  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={active || undefined}
      onClick={onPress}
      className={
        "flex h-14 items-center justify-center rounded-2xl border border-line text-xl font-medium " +
        "transition-transform duration-150 hover:brightness-110 active:scale-95 " +
        tones[tone]
      }
    >
      {icon ? <Delete className="size-5" strokeWidth={2} aria-hidden /> : label}
    </button>
  );
}
