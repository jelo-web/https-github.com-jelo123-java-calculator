import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Delete } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-yGSsHwCH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var OPERATOR_SYMBOL = {
	add: "+",
	subtract: "−",
	multiply: "×",
	divide: "÷"
};
var initialState = {
	display: "0",
	accumulator: null,
	operator: null,
	overwrite: true,
	error: null,
	expression: "",
	history: []
};
var MAX_DIGITS = 12;
var DIV_ZERO = "Can't divide by zero";
function parseDisplay(display) {
	const n = Number(display);
	return Number.isFinite(n) ? n : 0;
}
function formatResult(n) {
	if (!Number.isFinite(n)) return "Error";
	const rounded = Math.round(n * 0xe8d4a51000) / 0xe8d4a51000;
	if (Object.is(rounded, -0)) return "0";
	const abs = Math.abs(rounded);
	if (abs !== 0 && (abs >= 0xe8d4a51000 || abs < 1e-8)) return rounded.toExponential(6).replace(/\.?0+e/, "e");
	return String(rounded);
}
function apply(a, b, op) {
	if (op === "divide" && b === 0) return "div0";
	if (op === "add") return a + b;
	if (op === "subtract") return a - b;
	if (op === "multiply") return a * b;
	return a / b;
}
function digitCount(display) {
	return display.replace("-", "").replace(".", "").length;
}
function fresh(state, patch) {
	return {
		...initialState,
		history: state.history,
		...patch
	};
}
function reduce(state, action) {
	switch (action.type) {
		case "hydrate": return {
			...state,
			history: action.history.slice(0, 12)
		};
		case "recall": return fresh(state, {
			display: action.entry.result,
			expression: action.entry.expression,
			overwrite: true
		});
		case "clear": return fresh(state, {});
		case "digit": {
			const base = state.error ? fresh(state, {}) : state;
			if (base.overwrite) return {
				...base,
				display: action.digit,
				overwrite: false,
				expression: base.operator ? base.expression : "",
				error: null
			};
			if (digitCount(base.display) >= MAX_DIGITS) return base;
			if (base.display === "0") return {
				...base,
				display: action.digit
			};
			if (base.display === "-0") return {
				...base,
				display: `-${action.digit}`
			};
			return {
				...base,
				display: base.display + action.digit
			};
		}
		case "dot": {
			const base = state.error ? fresh(state, {}) : state;
			if (base.overwrite) return {
				...base,
				display: "0.",
				overwrite: false,
				expression: base.operator ? base.expression : "",
				error: null
			};
			if (base.display.includes(".")) return base;
			return {
				...base,
				display: `${base.display}.`
			};
		}
		case "sign":
			if (state.error) return state;
			if (state.display.startsWith("-")) return {
				...state,
				display: state.display.slice(1) || "0"
			};
			if (state.display === "0") return {
				...state,
				display: "-0",
				overwrite: false
			};
			return {
				...state,
				display: `-${state.display}`
			};
		case "percent":
			if (state.error) return state;
			return {
				...state,
				display: formatResult(parseDisplay(state.display) / 100),
				overwrite: true
			};
		case "backspace":
			if (state.error || state.overwrite) return state;
			if (state.display.length <= 1 || state.display.startsWith("-") && state.display.length <= 2) return {
				...state,
				display: "0",
				overwrite: true
			};
			return {
				...state,
				display: state.display.slice(0, -1)
			};
		case "operator": {
			if (state.error) return state;
			const current = parseDisplay(state.display);
			if (state.accumulator !== null && state.operator && !state.overwrite) {
				const result = apply(state.accumulator, current, state.operator);
				if (result === "div0") return {
					...state,
					error: DIV_ZERO,
					expression: `${formatResult(state.accumulator)} ÷ ${formatResult(current)}`
				};
				const text = formatResult(result);
				return {
					...state,
					display: text,
					accumulator: result,
					operator: action.operator,
					overwrite: true,
					error: null,
					expression: `${text} ${OPERATOR_SYMBOL[action.operator]}`
				};
			}
			return {
				...state,
				accumulator: current,
				operator: action.operator,
				overwrite: true,
				expression: `${formatResult(current)} ${OPERATOR_SYMBOL[action.operator]}`
			};
		}
		case "equals": {
			if (state.error || state.operator === null || state.accumulator === null) return state;
			const current = parseDisplay(state.display);
			const result = apply(state.accumulator, current, state.operator);
			const left = formatResult(state.accumulator);
			const right = formatResult(current);
			const expression = `${left} ${OPERATOR_SYMBOL[state.operator]} ${right}`;
			if (result === "div0") return {
				...state,
				error: DIV_ZERO,
				expression
			};
			const text = formatResult(result);
			const entry = {
				id: `${Date.now()}`,
				expression,
				result: text
			};
			return {
				...state,
				display: text,
				accumulator: null,
				operator: null,
				overwrite: true,
				error: null,
				expression,
				history: [entry, ...state.history].slice(0, 12)
			};
		}
		default: return state;
	}
}
var STORAGE_KEY = "tally-history";
var DIGITS = [
	"7",
	"8",
	"9",
	"4",
	"5",
	"6",
	"1",
	"2",
	"3",
	"0"
];
function isHistoryEntry(value) {
	if (!value || typeof value !== "object") return false;
	const entry = value;
	return typeof entry.id === "string" && typeof entry.expression === "string" && typeof entry.result === "string";
}
function Home() {
	const [state, dispatch] = (0, import_react.useReducer)(reduce, initialState);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed)) dispatch({
					type: "hydrate",
					history: parsed.filter(isHistoryEntry)
				});
			}
		} catch {}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify(state.history));
	}, [ready, state.history]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const tag = event.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			const key = event.key;
			if (/^[0-9]$/.test(key)) {
				dispatch({
					type: "digit",
					digit: key
				});
				return;
			}
			const ops = {
				"+": "add",
				"-": "subtract",
				"*": "multiply",
				"/": "divide"
			};
			if (ops[key]) {
				event.preventDefault();
				dispatch({
					type: "operator",
					operator: ops[key]
				});
				return;
			}
			if (key === "Enter" || key === "=") {
				event.preventDefault();
				dispatch({ type: "equals" });
				return;
			}
			if (key === ".") dispatch({ type: "dot" });
			else if (key === "Backspace") dispatch({ type: "backspace" });
			else if (key === "Escape") dispatch({ type: "clear" });
			else if (key === "%") dispatch({ type: "percent" });
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const readout = state.error ?? state.display;
	const compact = readout.length > 10;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-svh items-center justify-center bg-bg px-4 py-8 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full max-w-sm flex-col gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-baseline justify-between px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-sm font-medium tracking-widest text-muted uppercase",
						children: "Tally"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Calculator"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-panel border border-line bg-surface px-5 py-5",
					"aria-live": "polite",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-h-5 truncate text-right font-mono text-sm text-muted",
						children: state.expression || "\xA0"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 truncate text-right font-mono font-medium " + (state.error ? "text-3xl text-accent " : compact ? "text-3xl text-fg " : "text-5xl text-fg "),
						children: readout
					})]
				}),
				state.history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex max-h-28 flex-col gap-1 overflow-auto px-1",
					children: state.history.slice(0, 4).map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => dispatch({
							type: "recall",
							entry
						}),
						className: "flex w-full items-baseline justify-between gap-3 rounded-xl px-2 py-1 text-left font-mono text-sm text-muted hover:bg-surface hover:text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: entry.expression
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-fg",
							children: entry.result
						})]
					}) }, entry.id))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-1 text-sm text-muted",
					children: "Type or tap. History stays on this device."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid grid-cols-4 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: "C",
							tone: "ghost",
							onPress: () => dispatch({ type: "clear" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: "±",
							tone: "ghost",
							onPress: () => dispatch({ type: "sign" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: "%",
							tone: "ghost",
							onPress: () => dispatch({ type: "percent" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: OPERATOR_SYMBOL.divide,
							tone: "op",
							active: state.operator === "divide",
							onPress: () => dispatch({
								type: "operator",
								operator: "divide"
							})
						}),
						DIGITS.slice(0, 3).map((digit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: digit,
							onPress: () => dispatch({
								type: "digit",
								digit
							})
						}, digit)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: OPERATOR_SYMBOL.multiply,
							tone: "op",
							active: state.operator === "multiply",
							onPress: () => dispatch({
								type: "operator",
								operator: "multiply"
							})
						}),
						DIGITS.slice(3, 6).map((digit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: digit,
							onPress: () => dispatch({
								type: "digit",
								digit
							})
						}, digit)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: OPERATOR_SYMBOL.subtract,
							tone: "op",
							active: state.operator === "subtract",
							onPress: () => dispatch({
								type: "operator",
								operator: "subtract"
							})
						}),
						DIGITS.slice(6, 9).map((digit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: digit,
							onPress: () => dispatch({
								type: "digit",
								digit
							})
						}, digit)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: OPERATOR_SYMBOL.add,
							tone: "op",
							active: state.operator === "add",
							onPress: () => dispatch({
								type: "operator",
								operator: "add"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: "0",
							onPress: () => dispatch({
								type: "digit",
								digit: "0"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: ".",
							onPress: () => dispatch({ type: "dot" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: "Backspace",
							tone: "ghost",
							icon: true,
							onPress: () => dispatch({ type: "backspace" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
							label: "=",
							tone: "equals",
							onPress: () => dispatch({ type: "equals" })
						})
					]
				})
			]
		})
	});
}
function Key({ label, onPress, tone = "digit", active = false, icon = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		"aria-pressed": active || void 0,
		onClick: onPress,
		className: "flex h-14 items-center justify-center rounded-2xl border border-line text-xl font-medium transition-transform duration-150 hover:brightness-110 active:scale-95 " + {
			digit: "bg-key text-fg",
			op: active ? "bg-accent text-accent-ink" : "bg-key-strong text-fg",
			ghost: "bg-surface text-muted",
			equals: "bg-accent text-accent-ink"
		}[tone],
		children: icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, {
			className: "size-5",
			strokeWidth: 2,
			"aria-hidden": true
		}) : label
	});
}
//#endregion
export { Home as component };
